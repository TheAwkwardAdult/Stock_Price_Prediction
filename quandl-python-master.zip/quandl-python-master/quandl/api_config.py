class ApiConfig:
    api_key = None
    api_base = 'https://www.quandl.com/api/v3'
    api_version = None
    page_limit = 100
